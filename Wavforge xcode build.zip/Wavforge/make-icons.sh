#!/bin/bash
# Usage: ./make-icons.sh path/to/icon.png   (square, ideally 1024x1024)
# Fills Wavforge/Assets.xcassets/AppIcon.appiconset with every size.
set -e
SRC="$1"; [ -f "$SRC" ] || { echo "Usage: $0 icon.png"; exit 1; }
DIR="$(cd "$(dirname "$0")" && pwd)/Wavforge/Assets.xcassets/AppIcon.appiconset"
mk(){ sips -z $1 $1 "$SRC" --out "$DIR/$2" >/dev/null; }
mk 16 icon_16x16.png;     mk 32 icon_16x16@2x.png
mk 32 icon_32x32.png;     mk 64 icon_32x32@2x.png
mk 128 icon_128x128.png;  mk 256 icon_128x128@2x.png
mk 256 icon_256x256.png;  mk 512 icon_256x256@2x.png
mk 512 icon_512x512.png;  mk 1024 icon_512x512@2x.png
cat > "$DIR/Contents.json" <<'JSON'
{
  "images" : [
    { "filename":"icon_16x16.png","idiom":"mac","scale":"1x","size":"16x16" },
    { "filename":"icon_16x16@2x.png","idiom":"mac","scale":"2x","size":"16x16" },
    { "filename":"icon_32x32.png","idiom":"mac","scale":"1x","size":"32x32" },
    { "filename":"icon_32x32@2x.png","idiom":"mac","scale":"2x","size":"32x32" },
    { "filename":"icon_128x128.png","idiom":"mac","scale":"1x","size":"128x128" },
    { "filename":"icon_128x128@2x.png","idiom":"mac","scale":"2x","size":"128x128" },
    { "filename":"icon_256x256.png","idiom":"mac","scale":"1x","size":"256x256" },
    { "filename":"icon_256x256@2x.png","idiom":"mac","scale":"2x","size":"256x256" },
    { "filename":"icon_512x512.png","idiom":"mac","scale":"1x","size":"512x512" },
    { "filename":"icon_512x512@2x.png","idiom":"mac","scale":"2x","size":"512x512" }
  ],
  "info" : { "author":"xcode","version":1 }
}
JSON
echo "Done. Rebuild in Xcode (⇧⌘K then ⌘R)."
