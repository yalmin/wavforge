# WAVFORGE for Mac

1. Unzip, double-click `Wavforge.xcodeproj` (needs Xcode 14+ and macOS 12+).
2. If Xcode complains about signing: click the Wavforge target → Signing & Capabilities → set Team to "Personal Team" (or tick "Sign to Run Locally").
3. Press ⌘R.

Devices: the Devices button inside the app lists every output on your Mac (updates automatically).
Exports save to ~/Downloads. The app is not sandboxed (personal use).
