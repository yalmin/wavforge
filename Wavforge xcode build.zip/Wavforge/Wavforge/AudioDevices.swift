import Foundation
import CoreAudio

struct OutDevice: Identifiable, Hashable {
    let id: AudioDeviceID
    let name: String
}

/// Live list of every audio output on the Mac (speakers, headphones, Bluetooth, USB, HDMI, AirPlay once connected).
/// Updates automatically when something is plugged in, paired or removed.
final class AudioDevices: ObservableObject {
    @Published var devices: [OutDevice] = []
    @Published var current: AudioDeviceID = 0
    private let sys = AudioObjectID(kAudioObjectSystemObject)

    init() {
        refresh()
        let block: AudioObjectPropertyListenerBlock = { [weak self] _, _ in
            DispatchQueue.main.async { self?.refresh() }
        }
        for sel in [kAudioHardwarePropertyDevices, kAudioHardwarePropertyDefaultOutputDevice] {
            var a = AudioObjectPropertyAddress(mSelector: sel, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
            AudioObjectAddPropertyListenerBlock(sys, &a, DispatchQueue.main, block)
        }
    }

    func refresh() {
        var a = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDevices, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        AudioObjectGetPropertyDataSize(sys, &a, 0, nil, &size)
        var ids = [AudioDeviceID](repeating: 0, count: Int(size) / MemoryLayout<AudioDeviceID>.size)
        AudioObjectGetPropertyData(sys, &a, 0, nil, &size, &ids)
        devices = ids.filter(hasOutput).map { OutDevice(id: $0, name: name(of: $0)) }

        var d = AudioDeviceID(0)
        var s = UInt32(MemoryLayout<AudioDeviceID>.size)
        var b = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultOutputDevice, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        AudioObjectGetPropertyData(sys, &b, 0, nil, &s, &d)
        current = d
    }

    /// Make this device the Mac's output; the app's audio follows it.
    func select(_ id: AudioDeviceID) {
        var d = id
        var a = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultOutputDevice, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        AudioObjectSetPropertyData(sys, &a, 0, nil, UInt32(MemoryLayout<AudioDeviceID>.size), &d)
    }

    private func hasOutput(_ id: AudioDeviceID) -> Bool {
        var a = AudioObjectPropertyAddress(mSelector: kAudioDevicePropertyStreamConfiguration, mScope: kAudioDevicePropertyScopeOutput, mElement: kAudioObjectPropertyElementMain)
        var size: UInt32 = 0
        guard AudioObjectGetPropertyDataSize(id, &a, 0, nil, &size) == noErr, size > 0 else { return false }
        let buf = UnsafeMutableRawPointer.allocate(byteCount: Int(size), alignment: 16)
        defer { buf.deallocate() }
        guard AudioObjectGetPropertyData(id, &a, 0, nil, &size, buf) == noErr else { return false }
        let list = UnsafeMutableAudioBufferListPointer(buf.assumingMemoryBound(to: AudioBufferList.self))
        return list.reduce(0) { $0 + Int($1.mNumberChannels) } > 0
    }

    private func name(of id: AudioDeviceID) -> String {
        var a = AudioObjectPropertyAddress(mSelector: kAudioObjectPropertyName, mScope: kAudioObjectPropertyScopeGlobal, mElement: kAudioObjectPropertyElementMain)
        var n: CFString? = nil
        var size = UInt32(MemoryLayout<CFString?>.size)
        _ = withUnsafeMutablePointer(to: &n) { AudioObjectGetPropertyData(id, &a, 0, nil, &size, $0) }
        return (n as String?) ?? "Unknown device"
    }
}
