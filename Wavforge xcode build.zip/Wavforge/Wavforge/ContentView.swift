import SwiftUI
import WebKit
import CoreAudio

struct ContentView: View {
    @StateObject private var audio = AudioDevices()
    @StateObject private var cast = CastManager()

    var body: some View {
        WebView(audio: audio, cast: cast, devices: audio.devices, castDevices: cast.devices, current: audio.current, castStatus: cast.status)
    }
}

struct WebView: NSViewRepresentable {
    let audio: AudioDevices
    let cast: CastManager
    let devices: [OutDevice]
    let castDevices: [CastDevice]
    let current: AudioDeviceID
    let castStatus: String

    func makeCoordinator() -> Coordinator { Coordinator(audio: audio, cast: cast) }

    func makeNSView(context: Context) -> WKWebView {
        let cfg = WKWebViewConfiguration()
        cfg.mediaTypesRequiringUserActionForPlayback = []
        cfg.userContentController.add(context.coordinator, name: "wf")   // device picks from the page
        let web = WKWebView(frame: .zero, configuration: cfg)
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        context.coordinator.web = web
        if let url = Bundle.main.url(forResource: "index", withExtension: "html") {
            web.loadFileURL(url, allowingReadAccessTo: url.deletingLastPathComponent())
        }
        return web
    }

    func updateNSView(_ v: WKWebView, context: Context) {
        context.coordinator.push(devices: devices, castDevices: castDevices, current: current, status: castStatus)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate, WKScriptMessageHandler {
        let audio: AudioDevices
        let cast: CastManager
        weak var web: WKWebView?
        var last = "[]", cur: AudioDeviceID = 0
        init(audio: AudioDevices, cast: CastManager) { self.audio = audio; self.cast = cast }

        // Native device list -> the app's own Devices button
        func push(devices: [OutDevice], castDevices: [CastDevice], current: AudioDeviceID, status: String) {
            var arr = devices.map { ["id": Int($0.id), "name": $0.name, "cast": false] as [String: Any] }
            arr += castDevices.map { ["id": $0.id, "name": $0.name, "cast": true] as [String: Any] }
            if let d = try? JSONSerialization.data(withJSONObject: arr), let s = String(data: d, encoding: .utf8) { last = s }
            cur = current
            web?.evaluateJavaScript("window.__setNativeDevices&&window.__setNativeDevices(\(last),\(Int(cur)))")
            if let q = try? JSONSerialization.data(withJSONObject: [status]), let qs = String(data: q, encoding: .utf8) {
                web?.evaluateJavaScript("window.__setNativeStatus&&window.__setNativeStatus(\(qs)[0])")
            }
        }
        func webView(_ w: WKWebView, didFinish n: WKNavigation!) { push(devices: audio.devices, castDevices: cast.devices, current: audio.current, status: cast.status) }
        func userContentController(_ c: WKUserContentController, didReceive m: WKScriptMessage) {
            if let id = m.body as? Int { audio.select(AudioDeviceID(id)) }
            else if let d = m.body as? [String: Any] {
                if d["op"] as? String == "cast", let id = d["id"] as? String, let url = d["url"] as? String { cast.play(url: url, on: id) }
                if d["op"] as? String == "stop" { cast.stop() }
            }
        }

        // "Add songs" file dialog
        func webView(_ w: WKWebView, runOpenPanelWith p: WKOpenPanelParameters, initiatedByFrame f: WKFrameInfo,
                     completionHandler: @escaping ([URL]?) -> Void) {
            let o = NSOpenPanel()
            o.allowsMultipleSelection = p.allowsMultipleSelection
            o.canChooseDirectories = p.allowsDirectories
            o.begin { resp in
                guard resp == .OK else { completionHandler(nil); return }
                // Copy into our own temp folder: the web view's helper process isn't allowed to read
                // protected folders (Music, Downloads, Desktop…) even though you picked the file here.
                let fm = FileManager.default
                let base = fm.temporaryDirectory.appendingPathComponent("wavforge-picks", isDirectory: true)
                try? fm.removeItem(at: base)
                var out: [URL] = []
                for (i, u) in o.urls.enumerated() {
                    let dir = base.appendingPathComponent("\(i)", isDirectory: true)
                    try? fm.createDirectory(at: dir, withIntermediateDirectories: true)
                    let dest = dir.appendingPathComponent(u.lastPathComponent)
                    out.append((try? fm.copyItem(at: u, to: dest)) != nil ? dest : u)
                }
                completionHandler(out)
            }
        }

        // Export -> ~/Downloads
        func webView(_ w: WKWebView, decidePolicyFor a: WKNavigationAction, preferences: WKWebpagePreferences,
                     decisionHandler: @escaping (WKNavigationActionPolicy, WKWebpagePreferences) -> Void) {
            decisionHandler(a.shouldPerformDownload ? .download : .allow, preferences)
        }
        func webView(_ w: WKWebView, navigationAction: WKNavigationAction, didBecome d: WKDownload) { d.delegate = self }
        func webView(_ w: WKWebView, navigationResponse: WKNavigationResponse, didBecome d: WKDownload) { d.delegate = self }
        func download(_ d: WKDownload, decideDestinationUsing r: URLResponse, suggestedFilename: String,
                      completionHandler: @escaping (URL?) -> Void) {
            let dir = FileManager.default.urls(for: .downloadsDirectory, in: .userDomainMask)[0]
            let dest = dir.appendingPathComponent(suggestedFilename)
            try? FileManager.default.removeItem(at: dest)
            completionHandler(dest)
        }
    }
}
