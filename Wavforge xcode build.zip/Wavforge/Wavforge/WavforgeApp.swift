import SwiftUI

@main
struct WavforgeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView().frame(minWidth: 900, minHeight: 650)
        }
    }
}
