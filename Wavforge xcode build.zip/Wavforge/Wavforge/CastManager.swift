import Foundation
import Network

struct CastDevice: Identifiable, Hashable {
    let id: String
    let name: String
    let endpoint: NWEndpoint
}

/// Finds Chromecasts on the network and plays a file on them (Cast v2 protocol, Default Media Receiver).
final class CastManager: ObservableObject {
    @Published var devices: [CastDevice] = []
    @Published var status = "Searching for Cast devices…"
    private var browser: NWBrowser?
    private var conn: NWConnection?
    private var buffer = Data()
    private var heartbeat: Timer?
    private var pendingURL: String?
    private var transportId: String?
    private var sessionId: String?
    private let server = MediaServer()

    private let connNS = "urn:x-cast:com.google.cast.tp.connection"
    private let hbNS = "urn:x-cast:com.google.cast.tp.heartbeat"
    private let recvNS = "urn:x-cast:com.google.cast.receiver"
    private let mediaNS = "urn:x-cast:com.google.cast.media"
    private let appId = "CC1AD845"   // Default Media Receiver

    init() {
        server.start()
        let b = NWBrowser(for: .bonjourWithTXTRecord(type: "_googlecast._tcp", domain: nil), using: .tcp)
        b.browseResultsChangedHandler = { [weak self] results, _ in
            let list: [CastDevice] = results.compactMap { r in
                guard case let .service(name, _, _, _) = r.endpoint else { return nil }
                var friendly = name
                if case let .bonjour(txt) = r.metadata, let fn = txt["fn"] { friendly = fn }
                return CastDevice(id: name, name: friendly, endpoint: r.endpoint)
            }
            DispatchQueue.main.async { self?.devices = list }
        }
        b.stateUpdateHandler = { [weak self] state in
            DispatchQueue.main.async {
                switch state {
                case .ready:
                    self?.status = "Searching for Cast devices…"
                case .waiting, .failed:
                    self?.status = "Can’t search the network. Open System Settings → Privacy & Security → Local Network, turn on WAVFORGE, then reopen the app."
                default: break
                }
            }
        }
        b.start(queue: .main)
        browser = b
    }

    func play(url: String, on id: String) {
        guard let d = devices.first(where: { $0.id == id }) else { return }
        disconnect()
        pendingURL = url
        let tls = NWProtocolTLS.Options()
        sec_protocol_options_set_verify_block(tls.securityProtocolOptions, { _, _, done in done(true) }, .main)
        let c = NWConnection(to: d.endpoint, using: NWParameters(tls: tls, tcp: NWProtocolTCP.Options()))
        conn = c
        c.stateUpdateHandler = { [weak self] state in
            guard let self = self, case .ready = state else { return }
            self.send(self.connNS, "receiver-0", ["type": "CONNECT"])
            self.send(self.recvNS, "receiver-0", ["type": "LAUNCH", "appId": self.appId, "requestId": 1])
            self.readLoop()
            self.heartbeat = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
                guard let self = self else { return }
                self.send(self.hbNS, "receiver-0", ["type": "PING"])
            }
        }
        c.start(queue: .main)
    }

    func stop() {
        if let s = sessionId { send(recvNS, "receiver-0", ["type": "STOP", "requestId": 9, "sessionId": s]) }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in self?.disconnect() }
    }

    private func disconnect() {
        heartbeat?.invalidate(); heartbeat = nil
        conn?.cancel(); conn = nil
        buffer = Data(); transportId = nil; sessionId = nil
    }

    // MARK: protocol
    private func send(_ ns: String, _ dst: String, _ obj: [String: Any]) {
        guard let j = try? JSONSerialization.data(withJSONObject: obj) else { return }
        var m = Data()
        func varint(_ v: Int) -> Data { var x = v; var o = Data(); while x > 127 { o.append(UInt8((x & 127) | 128)); x >>= 7 }; o.append(UInt8(x)); return o }
        func field(_ tag: UInt8, _ bytes: Data) { m.append(tag); m.append(varint(bytes.count)); m.append(bytes) }
        m.append(contentsOf: [0x08, 0x00])
        field(0x12, Data("sender-0".utf8)); field(0x1a, Data(dst.utf8)); field(0x22, Data(ns.utf8))
        m.append(contentsOf: [0x28, 0x00])
        field(0x32, j)
        var len = UInt32(m.count).bigEndian
        var frame = Data(bytes: &len, count: 4)
        frame.append(m)
        conn?.send(content: frame, completion: .contentProcessed { _ in })
    }

    private func readLoop() {
        conn?.receive(minimumIncompleteLength: 1, maximumLength: 65536) { [weak self] data, _, done, err in
            guard let self = self else { return }
            if let d = data { self.buffer.append(d); self.drain() }
            if err == nil && !done { self.readLoop() }
        }
    }

    private func drain() {
        while buffer.count >= 4 {
            let n = buffer.prefix(4).reduce(0) { ($0 << 8) | Int($1) }
            guard buffer.count >= 4 + n else { return }
            let msg = [UInt8](buffer.subdata(in: buffer.startIndex + 4 ..< buffer.startIndex + 4 + n))
            buffer.removeSubrange(buffer.startIndex ..< buffer.startIndex + 4 + n)
            if let p = payload(msg) { handle(p) }
        }
    }

    private func payload(_ b: [UInt8]) -> [String: Any]? {
        var i = 0
        func rv() -> Int { var r = 0, s = 0; while i < b.count { let c = Int(b[i]); i += 1; r |= (c & 127) << s; if c < 128 { break }; s += 7 }; return r }
        while i < b.count {
            let t = rv(), f = t >> 3, w = t & 7
            if w == 0 { _ = rv() }
            else if w == 2 {
                let n = rv()
                guard i + n <= b.count else { return nil }
                if f == 6 { return (try? JSONSerialization.jsonObject(with: Data(b[i ..< i + n]))) as? [String: Any] }
                i += n
            } else { return nil }
        }
        return nil
    }

    private func handle(_ p: [String: Any]) {
        switch p["type"] as? String {
        case "PING":
            send(hbNS, "receiver-0", ["type": "PONG"])
        case "RECEIVER_STATUS":
            guard transportId == nil, let url = pendingURL,
                  let apps = (p["status"] as? [String: Any])?["applications"] as? [[String: Any]],
                  let app = apps.first(where: { ($0["appId"] as? String) == appId }),
                  let tid = app["transportId"] as? String else { return }
            transportId = tid
            sessionId = app["sessionId"] as? String
            send(connNS, tid, ["type": "CONNECT"])
            send(mediaNS, tid, ["type": "LOAD", "requestId": 2, "autoplay": true,
                                "media": ["contentId": url, "contentType": "audio/wav", "streamType": "BUFFERED"]])
        default: break
        }
    }
}

/// Tiny local web server: receives the rendered mix from the page and hands it to the Chromecast.
final class MediaServer {
    static let port: UInt16 = 8787
    private var listener: NWListener?
    private var media = Data()

    func start() {
        guard let p = NWEndpoint.Port(rawValue: Self.port), let l = try? NWListener(using: .tcp, on: p) else { return }
        l.newConnectionHandler = { [weak self] c in c.start(queue: .global()); self?.read(c, Data()) }
        l.start(queue: .global())
        listener = l
    }

    private func read(_ c: NWConnection, _ acc: Data) {
        c.receive(minimumIncompleteLength: 1, maximumLength: 1 << 20) { [weak self] data, _, done, err in
            guard let self = self else { return }
            var buf = acc
            if let d = data { buf.append(d) }
            let more = err == nil && !done
            guard let end = buf.range(of: Data("\r\n\r\n".utf8)) else { if more { self.read(c, buf) } else { c.cancel() }; return }
            let head = String(decoding: buf[buf.startIndex ..< end.lowerBound], as: UTF8.self)
            let body = Data(buf[end.upperBound...])
            var length = 0
            var range: String?
            for line in head.components(separatedBy: "\r\n") {
                let l = line.lowercased()
                if l.hasPrefix("content-length:") { length = Int(l.dropFirst(15).trimmingCharacters(in: .whitespaces)) ?? 0 }
                if l.hasPrefix("range:") { range = l.dropFirst(6).trimmingCharacters(in: .whitespaces) }
            }
            if body.count < length { if more { self.read(c, buf) } else { c.cancel() }; return }
            self.respond(c, head.components(separatedBy: "\r\n")[0], body, range)
        }
    }

    private func respond(_ c: NWConnection, _ request: String, _ body: Data, _ range: String?) {
        func send(_ status: String, _ extra: String, _ payload: Data) {
            var out = Data("HTTP/1.1 \(status)\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: *\r\n\(extra)Content-Length: \(payload.count)\r\nConnection: close\r\n\r\n".utf8)
            out.append(payload)
            c.send(content: out, completion: .contentProcessed { _ in c.cancel() })
        }
        if request.hasPrefix("OPTIONS") { send("204 No Content", "", Data()); return }
        if request.hasPrefix("POST /upload") {
            media = body
            let url = "http://\(Self.lanIP()):\(Self.port)/media.wav?t=\(Int(Date().timeIntervalSince1970))"
            send("200 OK", "Content-Type: application/json\r\n", Data("{\"url\":\"\(url)\"}".utf8)); return
        }
        if request.hasPrefix("GET /media.wav") && !media.isEmpty {
            var lo = 0, hi = media.count - 1
            var status = "200 OK"
            var extra = "Content-Type: audio/wav\r\nAccept-Ranges: bytes\r\n"
            if let r = range, r.hasPrefix("bytes=") {
                let parts = r.dropFirst(6).split(separator: "-", omittingEmptySubsequences: false)
                if let a = parts.first, let s = Int(a) { lo = s }
                if parts.count > 1, let e = Int(parts[1]) { hi = min(e, media.count - 1) }
                status = "206 Partial Content"
                extra += "Content-Range: bytes \(lo)-\(hi)/\(media.count)\r\n"
            }
            guard lo <= hi else { send("416 Range Not Satisfiable", "", Data()); return }
            send(status, extra, media.subdata(in: lo ..< hi + 1)); return
        }
        send("404 Not Found", "", Data())
    }

    static func lanIP() -> String {
        var addrs: UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&addrs) == 0, let first = addrs else { return "127.0.0.1" }
        defer { freeifaddrs(addrs) }
        var p: UnsafeMutablePointer<ifaddrs>? = first
        while let i = p?.pointee {
            if i.ifa_addr.pointee.sa_family == UInt8(AF_INET), (i.ifa_flags & UInt32(IFF_LOOPBACK)) == 0, (i.ifa_flags & UInt32(IFF_UP)) != 0 {
                var host = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                getnameinfo(i.ifa_addr, socklen_t(i.ifa_addr.pointee.sa_len), &host, socklen_t(host.count), nil, 0, NI_NUMERICHOST)
                return String(cString: host)
            }
            p = i.ifa_next
        }
        return "127.0.0.1"
    }
}
